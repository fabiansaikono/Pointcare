# Poincaré final complete icon pack v4

Dit is de volledige basisbibliotheek voor Poincaré, opgebouwd als originele, tintbare lijniconen.

## Inhoud

- `113` Android VectorDrawable XML-iconen
- `113` SVG-XML iconen
- `poincare-icons-final-complete-pack-v1.xml` — volledige mappingfile
- `poincare-icon-pack-v1.2-final-complete.xsd` — eenvoudige XSD met alle secties
- `icon-preview.html` — visuele preview
- `manifest.json` — telling van de assets

## Nieuwe thema-iconen

- dieren
- voertuigen
- seizoenen
- dagen
- maanden
- eten
- fruit
- groenten
- lichaam
- natuur
- ruimte
- muziek
- sport

## Nieuwe reward-iconen

- badge
- level
- ster
- poepje
- snoepje

## Nieuwe app/UI-iconen

- home
- terug
- volgende
- lock
- unlock
- audio
- hints
- success
- error
- close
- play
- pause
- refresh
- search
- info
- progress

## Nieuwe contenttype-iconen

- artikel
- oefenblad
- online oefening
- quiz
- spel

Alle iconen zijn wit/tintbaar en ontworpen voor een donkere Poincaré-achtergrond (`#050119`).
